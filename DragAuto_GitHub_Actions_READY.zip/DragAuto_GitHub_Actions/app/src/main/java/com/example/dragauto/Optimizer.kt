package com.example.dragauto

import android.content.Context
import kotlin.math.abs
import kotlin.math.max

object Optimizer {
    private val results = mutableListOf<Double>()
    private var currentOffset = 0L
    private var direction = 1L
    private var lastScore = Double.POSITIVE_INFINITY
    fun offset() = currentOffset + AdaptiveTuner.offset()
    @Synchronized fun record(time: Double, target: Double): Long {
        results += time
        AdaptiveTuner.update(time, target)
        val score = abs(time - target)
        if (score < lastScore) { lastScore = score; currentOffset += direction * 15L }
        else { direction = -direction; currentOffset += direction * 15L }
        currentOffset = currentOffset.coerceIn(-250L, 250L)
        return offset()
    }
}
