package com.example.dragauto

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * Foreground service owning the MediaProjection session.
 * Frames are sampled and passed to TimerReader; OCR results are kept in
 * SharedPreferences so the automation service can consume the latest value.
 */
class MediaProjectionCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.example.dragauto.MEDIA_START"
        const val ACTION_STOP = "com.example.dragauto.MEDIA_STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL_ID = "screen_capture"
        private const val NOTIFICATION_ID = 41
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastPreviewWriteMs = 0L
    @Volatile private var lastOcrMs = 0L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = intent.parcelableIntentExtra(EXTRA_RESULT_DATA) ?: return START_NOT_STICKY
                startForeground(
                    NOTIFICATION_ID,
                    NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle("Drag Auto")
                        .setContentText("Захват экрана активен")
                        .setSmallIcon(android.R.drawable.ic_menu_view)
                        .setOngoing(true)
                        .build(),
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
                )
                startCapture(resultCode, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        stopCapture(releaseProjection = false)
        val metrics = DisplayMetrics()
        val wm = getSystemService(android.view.WindowManager::class.java)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                virtualDisplay?.release()
                virtualDisplay = null
                imageReader?.close()
                imageReader = null
                projection = null
            }
        }
        projection!!.registerCallback(projectionCallback!!, android.os.Handler(mainLooper))
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader ->
            reader.acquireLatestImage()?.use { image ->
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(plane.buffer)
                val frame = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                bitmap.recycle()

                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastPreviewWriteMs >= 500L) {
                    lastPreviewWriteMs = now
                    writePreview(frame)
                }

                val prefs = getSharedPreferences("run", 0)
                val ocrNow = android.os.SystemClock.elapsedRealtime()
                if (ocrNow - lastOcrMs < 120L) { frame.recycle(); return@setOnImageAvailableListener }
                lastOcrMs = ocrNow
                val rx = prefs.getFloat("roi_x", 0f).coerceIn(0f, 1f)
                val ry = prefs.getFloat("roi_y", 0f).coerceIn(0f, 1f)
                val rw = prefs.getFloat("roi_w", 1f).coerceIn(0.05f, 1f - rx)
                val rh = prefs.getFloat("roi_h", 1f).coerceIn(0.05f, 1f - ry)
                val left = (rx * width).roundToInt().coerceIn(0, width - 1)
                val top = (ry * height).roundToInt().coerceIn(0, height - 1)
                val right = (left + rw * width).roundToInt().coerceIn(left + 1, width)
                val bottom = (top + rh * height).roundToInt().coerceIn(top + 1, height)
                val cropped = Bitmap.createBitmap(frame, left, top, right - left, bottom - top)
                frame.recycle()

                TimerReader.readSeconds(cropped, executor) { seconds ->
                    if (seconds != null) {
                        prefs.edit().putFloat("screen_timer", seconds.toFloat()).putString(DebugState.STATUS, "OCR активен").apply()
                    } else {
                        prefs.edit().putString(DebugState.STATUS, "OCR ищет таймер").apply()
                    }
                    cropped.recycle()
                }
            }
        }, null)

        virtualDisplay = projection!!.createVirtualDisplay(
            "DragAutoCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )
    }



    private fun writePreview(frame: Bitmap) {
        try {
            FileOutputStream(File(filesDir, "latest_frame.jpg")).use { out ->
                frame.compress(Bitmap.CompressFormat.JPEG, 65, out)
            }
        } catch (_: Exception) { }
    }

    private fun stopCapture(releaseProjection: Boolean = true) {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        if (releaseProjection) {
            projectionCallback?.let { cb -> projection?.unregisterCallback(cb) }
            projection?.stop()
        }
        projectionCallback = null
        projection = null
        if (releaseProjection) stopForeground(STOP_FOREGROUND_REMOVE)
        if (releaseProjection) stopSelf()
    }

    override fun onDestroy() {
        stopCapture()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private fun Intent.parcelableIntentExtra(key: String): Intent? =
    if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, Intent::class.java)
    else @Suppress("DEPRECATION") getParcelableExtra(key)
