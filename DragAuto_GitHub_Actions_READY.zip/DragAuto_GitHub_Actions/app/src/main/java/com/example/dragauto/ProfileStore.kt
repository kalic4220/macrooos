package com.example.dragauto

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ProfileStore {
    private const val PREFS = "profiles"
    private const val KEY = "items"
    private const val DEFAULT = "Default"

    fun names(context: Context): MutableList<String> {
        val a = runCatching { JSONArray(context.getSharedPreferences(PREFS, 0).getString(KEY, "[]")) }.getOrDefault(JSONArray())
        val names = mutableListOf<String>()
        for (i in 0 until a.length()) names += a.getJSONObject(i).optString("name")
        if (!names.contains(DEFAULT)) names.add(0, DEFAULT)
        return names.distinct().toMutableList()
    }

    fun save(context: Context, name: String, target: Double, start: Long, shifts: String, warm: Long) {
        val clean = name.trim().ifEmpty { DEFAULT }
        val prefs = context.getSharedPreferences(PREFS, 0)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrDefault(JSONArray())
        val out = JSONArray()
        var replaced = false
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("name") == clean) {
                out.put(JSONObject().apply { put("name", clean); put("target", target); put("start", start); put("shifts", shifts); put("warm", warm) })
                replaced = true
            } else out.put(o)
        }
        if (!replaced) out.put(JSONObject().apply { put("name", clean); put("target", target); put("start", start); put("shifts", shifts); put("warm", warm) })
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    fun load(context: Context, name: String): JSONObject? {
        val a = runCatching { JSONArray(context.getSharedPreferences(PREFS, 0).getString(KEY, "[]")) }.getOrDefault(JSONArray())
        for (i in 0 until a.length()) if (a.getJSONObject(i).optString("name") == name) return a.getJSONObject(i)
        return null
    }
}
