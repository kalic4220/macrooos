package com.example.dragauto

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * Autonomous coordinate-descent learner.
 * In AUTO mode the user does not need to enter shift timings.
 * After each completed run, the learner changes one shift and keeps/reverts
 * the change according to the run score (distance from target).
 */
object AutoShiftLearner {
    private const val PREFS = "auto_learning"
    private const val KEY = "profiles"
    private const val DEFAULT = "1050,1450,1750,2050,2350"
    private const val STEP = 25L
    private const val MIN = 500L
    private const val MAX = 3500L

    private data class State(
        val shifts: MutableList<Long>,
        var nextIndex: Int = 0,
        var direction: Long = 1,
        var step: Long = STEP,
        var bestScore: Double? = null,
        var lastScore: Double? = null,
        var pendingIndex: Int = 0,
        var pendingShifts: MutableList<Long> = shifts.toMutableList()
    )

    private fun loadAll(context: Context): JSONObject =
        runCatching {
            JSONObject(context.getSharedPreferences(PREFS, 0).getString(KEY, "{}"))
        }.getOrDefault(JSONObject())

    private fun saveAll(context: Context, all: JSONObject) {
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, all.toString()).apply()
    }

    private fun parse(value: String): MutableList<Long> =
        value.split(",").mapNotNull { it.trim().toLongOrNull() }
            .filter { it in MIN..MAX }.take(8).toMutableList()
            .ifEmpty { DEFAULT.split(",").map { it.toLong() }.toMutableList() }

    private fun state(context: Context, profile: String, fallback: String): State {
        val all = loadAll(context)
        val o = all.optJSONObject(profile)
        if (o == null) return State(parse(fallback))
        val a = o.optJSONArray("shifts")
        val shifts = if (a != null) buildList {
            for (i in 0 until a.length()) add(a.optLong(i))
        }.toMutableList() else parse(fallback)
        return State(
            shifts = if (shifts.isEmpty()) parse(fallback) else shifts,
            nextIndex = o.optInt("nextIndex", 0),
            direction = if (o.optLong("direction", 1) < 0) -1 else 1,
            step = o.optLong("step", STEP).coerceIn(5, 100),
            bestScore = if (o.has("bestScore")) o.optDouble("bestScore") else null,
            lastScore = if (o.has("lastScore")) o.optDouble("lastScore") else null,
            pendingIndex = o.optInt("pendingIndex", 0),
            pendingShifts = if (o.optJSONArray("pending") != null) buildList {
                val p = o.optJSONArray("pending")!!
                for (i in 0 until p.length()) add(p.optLong(i))
            }.toMutableList() else shifts.toMutableList()
        )
    }

    private fun persist(context: Context, profile: String, s: State) {
        val all = loadAll(context)
        all.put(profile, JSONObject().apply {
            put("shifts", JSONArray(s.shifts))
            put("nextIndex", s.nextIndex)
            put("direction", s.direction)
            put("step", s.step)
            if (s.bestScore != null) put("bestScore", s.bestScore)
            if (s.lastScore != null) put("lastScore", s.lastScore)
            put("pendingIndex", s.pendingIndex)
            put("pending", JSONArray(s.pendingShifts))
        })
        saveAll(context, all)
    }

    /** Current timings used by AUTO mode. */
    @Synchronized
    fun current(context: Context, profile: String, fallback: String): String {
        val s = state(context, profile, fallback)
        persist(context, profile, s)
        return s.shifts.joinToString(",")
    }

    /**
     * Called after a run. The first result establishes a baseline.
     * Afterwards one gear timing is perturbed; if score improves the change
     * is kept, otherwise direction is reversed and the step is reduced.
     */
    @Synchronized
    fun record(context: Context, profile: String, fallback: String, actual: Double, target: Double): String {
        if (!actual.isFinite() || !target.isFinite()) return current(context, profile, fallback)
        val s = state(context, profile, fallback)
        val score = abs(actual - target)

        if (s.bestScore == null) {
            s.bestScore = score
            s.lastScore = score
            s.pendingIndex = s.nextIndex.coerceIn(0, s.shifts.lastIndex)
            s.pendingShifts = s.shifts.toMutableList()
            s.pendingShifts[s.pendingIndex] = (s.shifts[s.pendingIndex] + s.direction * s.step).coerceIn(MIN, MAX)
            s.shifts = s.pendingShifts.toMutableList()
        } else {
            val previous = s.lastScore ?: score
            if (score <= previous) {
                s.bestScore = minOf(s.bestScore ?: score, score)
                // Keep candidate and try another step in the same direction.
                s.step = s.step.coerceIn(5, 100)
            } else {
                // Revert candidate and search the opposite direction.
                s.shifts = s.pendingShifts.toMutableList().also {
                    val idx = s.pendingIndex.coerceIn(0, it.lastIndex)
                    it[idx] = (it[idx] - s.direction * s.step).coerceIn(MIN, MAX)
                }
                s.direction *= -1
                s.step = (s.step / 2).coerceAtLeast(5)
                s.nextIndex = (s.pendingIndex + 1) % s.shifts.size
                s.pendingIndex = s.nextIndex
                s.pendingShifts = s.shifts.toMutableList()
                val idx = s.pendingIndex
                s.pendingShifts[idx] = (s.shifts[idx] + s.direction * s.step).coerceIn(MIN, MAX)
                s.shifts = s.pendingShifts.toMutableList()
            }
            s.lastScore = score
        }
        persist(context, profile, s)
        return s.shifts.joinToString(",")
    }

    fun summary(context: Context, profile: String): String {
        val s = state(context, profile, DEFAULT)
        val best = s.bestScore?.let { "%.3f".format(it) } ?: "—"
        return "AUTO: шаг ${s.step} мс • следующая передача ${s.pendingIndex + 1} • ошибка $best с"
    }

    fun reset(context: Context, profile: String) {
        val all = loadAll(context)
        all.remove(profile)
        saveAll(context, all)
    }
}
